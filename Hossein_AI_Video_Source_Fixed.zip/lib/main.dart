import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:convert';

const emerald = Color(0xFF00A878);
const bg = Color(0xFF07110F);
const panel = Color(0xFF10201C);

void main() => runApp(const HosseinAiApp());

class HosseinAiApp extends StatelessWidget {
  const HosseinAiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Hossein AI Video',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: emerald, brightness: Brightness.dark),
      useMaterial3: true,
      fontFamily: 'Roboto',
      cardTheme: const CardThemeData(color: panel, surfaceTintColor: Colors.transparent),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const HomePage(),
  );
}

class Engine {
  final String name, detail, url, availability;
  final IconData icon;
  const Engine(this.name, this.detail, this.url, this.availability, this.icon);
}

const engines = [
  Engine('Hugging Face Spaces', 'دموهای عمومی؛ ممکن است صف یا محدودیت داشته باشند',
    'https://huggingface.co/spaces', 'رایگانِ وابسته به دمو', Icons.hub_outlined),
  Engine('Google Flow', 'ساخت ویدیو در محیط رسمی گوگل؛ سهمیه و شرایط حساب متغیر است',
    'https://labs.google/fx/tools/flow', 'بررسی سهمیه در سرویس', Icons.movie_creation_outlined),
  Engine('Wan 2.2', 'مدل با وزن‌های قابل دریافت؛ اجرای کامل نیازمند GPU ابری یا رایانه است',
    'https://github.com/Wan-Video/Wan2.2', 'مدل باز؛ پردازش رایگان تضمین نیست', Icons.auto_awesome),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String selectedEngine = engines.first.name;
  String mode = 'عکس به ویدیو';
  String ratio = '9:16';
  String quality = 'بالاترین کیفیت موجود';
  String prompt = '';
  String? imagePath;
  List<Map<String, String>> projects = [];

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('projects');
    if (raw != null) {
      final list = (jsonDecode(raw) as List).cast<Map>();
      setState(() => projects = list.map((e) => e.map((k,v) => MapEntry(k.toString(), v.toString()))).toList());
    }
  }
  Future<void> _saveProject() async {
    if (prompt.trim().isEmpty) { _snack('ابتدا توضیح ویدیو را بنویس.'); return; }
    final p = await SharedPreferences.getInstance();
    final item = <String,String>{
      'prompt': prompt.trim(), 'engine': selectedEngine, 'mode': mode,
      'ratio': ratio, 'quality': quality, 'date': DateTime.now().toString().substring(0,16),
      'image': imagePath ?? '',
    };
    projects.insert(0, item);
    await p.setString('projects', jsonEncode(projects));
    setState(() {});
    await Clipboard.setData(ClipboardData(text: prompt.trim()));
    _snack('پروژه ذخیره شد و پرامپت کپی شد. سرویس انتخابی را باز کن.');
    final e = engines.firstWhere((x) => x.name == selectedEngine);
    await _open(e.url);
  }
  Future<void> _pickImage() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (x != null) setState(() => imagePath = x.path);
  }
  Future<void> _open(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) _snack('باز کردن لینک ممکن نشد.');
  }
  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s), behavior: SnackBarBehavior.floating));

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: bg, titleSpacing: 18,
        title: const Row(children: [
          Icon(Icons.play_circle_fill, color: emerald, size: 28),
          SizedBox(width: 9),
          Text('HOSSEIN AI VIDEO', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: .7)),
        ]),
        actions: [IconButton(onPressed: () => _showAbout(), icon: const Icon(Icons.info_outline))],
      ),
      body: IndexedStack(index: tab, children: [_studio(), _enginesPage(), _historyPage()]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel, indicatorColor: emerald.withOpacity(.22),
        selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.movie_filter_outlined), selectedIcon: Icon(Icons.movie_filter), label: 'استودیو'),
          NavigationDestination(icon: Icon(Icons.hub_outlined), selectedIcon: Icon(Icons.hub), label: 'موتورها'),
          NavigationDestination(icon: Icon(Icons.video_library_outlined), selectedIcon: Icon(Icons.video_library), label: 'پروژه‌ها'),
        ],
      ),
    );
  }

  Widget _studio() => ListView(padding: const EdgeInsets.all(16), children: [
    Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(colors: [Color(0xFF124B3A), Color(0xFF10201C)], begin: Alignment.topRight, end: Alignment.bottomLeft),
        border: Border.all(color: emerald.withOpacity(.35)),
      ),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('استودیوی هوش مصنوعی', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        SizedBox(height: 7),
        Text('ایده‌ات را آماده کن؛ موتور مناسب را انتخاب کن و در سرویس تولید کن.', style: TextStyle(color: Colors.white70, height: 1.6)),
      ]),
    ),
    const SizedBox(height: 20),
    const _SectionTitle('نوع تولید'),
    Wrap(spacing: 8, children: ['عکس به ویدیو','متن به ویدیو'].map((v) => ChoiceChip(label: Text(v), selected: mode == v, onSelected: (_) => setState(() => mode = v)).toWidget()).toList()),
    if (mode == 'عکس به ویدیو') ...[
      const SizedBox(height: 16),
      OutlinedButton.icon(onPressed: _pickImage, icon: const Icon(Icons.add_photo_alternate_outlined), label: Text(imagePath == null ? 'انتخاب عکس از گالری' : 'عکس انتخاب شد؛ تغییر عکس')),
      if (imagePath != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(imagePath!.split('/').last, style: const TextStyle(color: Colors.white54))),
    ],
    const SizedBox(height: 18),
    const _SectionTitle('پرامپت یا توضیح ویدیو'),
    TextField(
      minLines: 4, maxLines: 7, onChanged: (v) => prompt = v,
      decoration: const InputDecoration(hintText: 'مثلاً: تصویر را به یک ویدیوی سینمایی با حرکت طبیعی دوربین و نورپردازی حرفه‌ای تبدیل کن...', alignLabelWithHint: true),
    ),
    const SizedBox(height: 18),
    const _SectionTitle('موتور تولید'),
    DropdownButtonFormField<String>(
      value: selectedEngine, decoration: const InputDecoration(),
      items: engines.map((e) => DropdownMenuItem(value: e.name, child: Text(e.name, overflow: TextOverflow.ellipsis))).toList(),
      onChanged: (v) => setState(() => selectedEngine = v!),
    ),
    const SizedBox(height: 16),
    Row(children: [
      Expanded(child: _dropdown('نسبت تصویر', ratio, ['9:16','16:9','1:1'], (v) => setState(() => ratio = v))),
      const SizedBox(width: 10),
      Expanded(child: _dropdown('کیفیت', quality, ['بالاترین کیفیت موجود','کیفیت متعادل','تولید سریع‌تر'], (v) => setState(() => quality = v))),
    ]),
    const SizedBox(height: 22),
    FilledButton.icon(
      style: FilledButton.styleFrom(backgroundColor: emerald, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(vertical: 16)),
      onPressed: _saveProject, icon: const Icon(Icons.rocket_launch), label: const Text('آماده‌سازی و بازکردن موتور تولید', style: TextStyle(fontWeight: FontWeight.bold)),
    ),
    const SizedBox(height: 12),
    const Text('توجه: این نسخه پرامپت و پروژه را مدیریت می‌کند و سرویس انتخابی را باز می‌کند. تولید خودکار داخل برنامه تا زمان فراهم‌شدن API رسمی هر موتور فعال نیست.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.7)),
  ]);

  Widget _dropdown(String label, String value, List<String> values, ValueChanged<String> onChanged) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
    const SizedBox(height: 7),
    DropdownButtonFormField<String>(value: value, isExpanded: true, items: values.map((v) => DropdownMenuItem(value: v, child: Text(v, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)))).toList(), onChanged: (v) => onChanged(v!)),
  ]);

  Widget _enginesPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('موتورهای موجود', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('وضعیت رایگان‌بودن، سهمیه و دسترسی ممکن است تغییر کند؛ پیش از استفاده شرایط رسمی را بررسی کن.', style: TextStyle(color: Colors.white60, height: 1.6)),
    const SizedBox(height: 12),
    ...engines.map((e) => Card(child: ListTile(
      contentPadding: const EdgeInsets.all(12),
      leading: CircleAvatar(backgroundColor: emerald.withOpacity(.15), child: Icon(e.icon, color: emerald)),
      title: Text(e.name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Padding(padding: const EdgeInsets.only(top: 6), child: Text('${e.detail}\nوضعیت: ${e.availability}', style: const TextStyle(height: 1.5, color: Colors.white60))),
      isThreeLine: true,
      trailing: IconButton(icon: const Icon(Icons.open_in_new, color: emerald), onPressed: () => _open(e.url)),
    ))),
  ]);

  Widget _historyPage() => projects.isEmpty
    ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.video_library_outlined, size: 54, color: emerald), SizedBox(height: 12), Text('هنوز پروژه‌ای ذخیره نشده است'), Text('پروژه‌های آماده‌سازی‌شده اینجا نمایش داده می‌شوند.', style: TextStyle(color: Colors.white54))]))
    : ListView.builder(padding: const EdgeInsets.all(12), itemCount: projects.length, itemBuilder: (c,i) {
      final p = projects[i];
      return Card(child: ListTile(
        leading: const Icon(Icons.movie_creation_outlined, color: emerald),
        title: Text(p['prompt'] ?? '', maxLines: 2, overflow: TextOverflow.ellipsis),
        subtitle: Text('${p['engine']} • ${p['ratio']} • ${p['date']}'),
        trailing: IconButton(icon: const Icon(Icons.copy), onPressed: () async { await Clipboard.setData(ClipboardData(text: p['prompt'] ?? '')); _snack('پرامپت کپی شد.'); }),
      ));
    });

  void _showAbout() => showAboutDialog(context: context, applicationName: 'Hossein AI Video', applicationVersion: '1.0.0', applicationLegalese: 'نسخه آغازین مدیریت موتورهای تولید ویدیو. این برنامه وابسته به سرویس‌های بیرونی است.');
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 9), child: Text(text, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)));
}

extension on Widget {
  Widget toWidget() => this;
}
